import xbmcplugin
import xbmcgui
import sys
import urllib.request
import re

def get_video_link(html_url):
    try:
        # Fazer a requisição para a página
        response = urllib.request.urlopen(html_url)
        html_content = response.read().decode('utf-8')
        
        # Procurar por um link de vídeo (MP4) no HTML
        video_url = None
        match = re.search(r'(https?://[^\s]+\.mp4)', html_content)
        
        if match:
            video_url = match.group(1)
        
        return video_url
    except Exception as e:
        print(f"Erro ao obter o link do vídeo: {e}")
        return None

def main():
    # Obter informações do plugin
    base_url = sys.argv[0]
    handle = int(sys.argv[1])

    # URL da página HTML com o vídeo
    html_url = 'https://redecanais.ec/luccas-e-gi-em-dinossauros-nacional-2024-1080p_6ffe9d994.html'  # Substitua pelo seu URL
    video_url = get_video_link(html_url)

    if video_url:
        # Função para adicionar o link do vídeo ao menu do Kodi
        def add_menu_item(label, url, is_folder):
            list_item = xbmcgui.ListItem(label=label)
            xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=is_folder)

        # Adicionar o vídeo ao menu
        add_menu_item('Assistir Luccas e Gi em Dinossauros', video_url, False)

        # Finalizar a exibição do diretório no Kodi
        xbmcplugin.endOfDirectory(handle)
    else:
        # Caso o link não seja encontrado, mostrar uma mensagem de erro
        xbmcgui.Dialog().ok('Erro', 'Não foi possível encontrar o link do vídeo.')

if __name__ == '__main__':
    main()

